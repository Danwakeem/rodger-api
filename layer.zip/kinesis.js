"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.kinesis';
function eventType(event = {}) {
    const { Records = [] } = event;
    const [firstEvent = {}] = Records;
    const { eventSource } = firstEvent;
    // test is for firstEvent.eventVersion === '1.0'
    return eventSource === 'aws:kinesis' ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=kinesis.js.map