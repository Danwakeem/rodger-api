export default function eventType(e?: any): false | "aws.alexaskill";
//# sourceMappingURL=alexaSkill.d.ts.map