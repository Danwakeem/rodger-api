"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const sdk_trace_node_1 = require("@opentelemetry/sdk-trace-node");
const sdk_trace_base_1 = require("@opentelemetry/sdk-trace-base");
const sdk_metrics_base_1 = require("@opentelemetry/sdk-metrics-base");
const exporter_metrics_otlp_proto_1 = require("@opentelemetry/exporter-metrics-otlp-proto");
const instrumentation_1 = require("@opentelemetry/instrumentation");
const resource_detector_aws_1 = require("@opentelemetry/resource-detector-aws");
const resources_1 = require("@opentelemetry/resources");
const instrumentation_aws_sdk_1 = require("@opentelemetry/instrumentation-aws-sdk");
const api_1 = require("@opentelemetry/api");
const core_1 = require("@opentelemetry/core");
// Use require statements for instrumentation to avoid having to have transitive dependencies on all the typescript
// definitions.
const instrumentation_aws_lambda_1 = require("@opentelemetry/instrumentation-aws-lambda");
const { DnsInstrumentation } = require('@opentelemetry/instrumentation-dns');
const { ExpressInstrumentation } = require('@opentelemetry/instrumentation-express');
const { GraphQLInstrumentation } = require('@opentelemetry/instrumentation-graphql');
const { GrpcInstrumentation } = require('@opentelemetry/instrumentation-grpc');
const { HapiInstrumentation } = require('@opentelemetry/instrumentation-hapi');
const { HttpInstrumentation } = require('@opentelemetry/instrumentation-http');
const { IORedisInstrumentation } = require('@opentelemetry/instrumentation-ioredis');
const { KoaInstrumentation } = require('@opentelemetry/instrumentation-koa');
const { MongoDBInstrumentation } = require('@opentelemetry/instrumentation-mongodb');
const { MySQLInstrumentation } = require('@opentelemetry/instrumentation-mysql');
const { NetInstrumentation } = require('@opentelemetry/instrumentation-net');
const { PgInstrumentation } = require('@opentelemetry/instrumentation-pg');
const { RedisInstrumentation } = require('@opentelemetry/instrumentation-redis');
const exporter_otlp_proto_1 = require("@opentelemetry/exporter-otlp-proto");
const index_1 = require("./eventDetection/index");
console.log('Registering OpenTelemetry');
const meterProvider = new sdk_metrics_base_1.MeterProvider({
    exporter: new exporter_metrics_otlp_proto_1.OTLPMetricExporter(),
    interval: 60000,
});
const slsMeter = meterProvider.getMeter('serverless-meter');
const counter = slsMeter.createCounter('faas.invoke');
const errorCount = slsMeter.createCounter('faas.error');
let attributes = {};
const instrumentations = [
    new instrumentation_aws_sdk_1.AwsInstrumentation({
        suppressInternalInstrumentation: true,
    }),
    new instrumentation_aws_lambda_1.AwsLambdaInstrumentation({
        requestHook: (span, { event = {} }) => {
            const eventType = index_1.detectEventType(event);
            attributes = {
                'faas.eventType': eventType || '',
            };
            if (eventType === 'aws.apigateway.http') {
                attributes['faas.source'] = 'aws.apigateway';
                attributes['faas.accountId'] = event.requestContext.accountId;
                attributes['faas.apiId'] = event.requestContext.apiId;
                attributes['faas.resourceId'] = event.requestContext.resourceId;
                attributes['faas.domainPrefix'] = event.requestContext.domainPrefix;
                attributes['faas.domain'] = event.requestContext.domainName;
                attributes['faas.requestId'] = event.requestContext.requestId;
                attributes['faas.extendedRequestId'] = event.requestContext.extendedRequestId;
                attributes['faas.requestTime'] = event.requestContext.requestTime;
                attributes['faas.requestTimeEpoch'] = event.requestContext.requestTimeEpoch;
                attributes['faas.httpPath'] = event.requestContext.resourcePath;
                attributes['faas.httpMethod'] = event.requestContext.httpMethod;
                attributes['faas.xTraceId'] = event.headers && event.headers['X-Amzn-Trace-Id'];
                attributes['faas.userAgent'] = event.headers && event.headers['User-Agent'];
            }
            else if (eventType === 'aws.apigatewayv2.http') {
                attributes['faas.source'] = 'aws.apigatewayv2';
                attributes['faas.accountId'] = event.requestContext.accountId;
                attributes['faas.apiId'] = event.requestContext.apiId;
                attributes['faas.domainPrefix'] = event.requestContext.domainPrefix;
                attributes['faas.domain'] = event.requestContext.domainName;
                attributes['faas.requestId'] = event.requestContext.requestId;
                attributes['faas.requestTime'] = event.requestContext.time;
                attributes['faas.requestTimeEpoch'] = event.requestContext.timeEpoch;
                attributes['faas.httpPath'] = event.requestContext.http.path;
                attributes['faas.httpMethod'] = event.requestContext.http.method;
                attributes['faas.xTraceId'] = event.headers && event.headers['x-amzn-trace-id'];
                attributes['faas.userAgent'] = event.headers && event.headers['user-agent'];
            }
            Object.keys((attributes)).map((key) => span.setAttribute(key, attributes[key]));
            counter.add(1, attributes);
        },
        responseHook: (span, { err, res }) => {
            let jsonBody = {};
            try {
                jsonBody = JSON.parse(res.body);
            }
            catch (error) { }
            if (err instanceof Error) {
                span.setAttribute('faas.error', err.message);
                errorCount.add(1, attributes);
            }
            else if (Array.isArray(jsonBody.errors) && jsonBody.errors.length > 0) {
                span.setAttribute('faas.error', jsonBody.errors[0].message);
                errorCount.add(1, attributes);
            }
        }
    }),
    new DnsInstrumentation(),
    new ExpressInstrumentation(),
    new GraphQLInstrumentation(),
    new GrpcInstrumentation(),
    new HapiInstrumentation(),
    new HttpInstrumentation(),
    new IORedisInstrumentation(),
    new KoaInstrumentation(),
    new MongoDBInstrumentation(),
    new MySQLInstrumentation(),
    new NetInstrumentation(),
    new PgInstrumentation(),
    new RedisInstrumentation(),
];
// configure lambda logging
const logLevel = core_1.getEnv().OTEL_LOG_LEVEL;
api_1.diag.setLogger(new api_1.DiagConsoleLogger(), logLevel);
// Register instrumentations synchronously to ensure code is patched even before provider is ready.
instrumentation_1.registerInstrumentations({
    instrumentations,
});
async function initializeProvider() {
    const resource = await resources_1.detectResources({
        detectors: [resource_detector_aws_1.awsLambdaDetector, resources_1.envDetector, resources_1.processDetector],
    });
    let config = {
        resource,
    };
    if (typeof configureTracer === 'function') {
        config = configureTracer(config);
    }
    const tracerProvider = new sdk_trace_node_1.NodeTracerProvider(config);
    if (typeof configureTracerProvider === 'function') {
        configureTracerProvider(tracerProvider);
    }
    else {
        // defaults
        tracerProvider.addSpanProcessor(new sdk_trace_base_1.BatchSpanProcessor(new exporter_otlp_proto_1.OTLPTraceExporter()));
    }
    // logging for debug
    if (logLevel === api_1.DiagLogLevel.DEBUG) {
        tracerProvider.addSpanProcessor(new sdk_trace_base_1.SimpleSpanProcessor(new sdk_trace_base_1.ConsoleSpanExporter()));
    }
    let sdkRegistrationConfig = {};
    if (typeof configureSdkRegistration === 'function') {
        sdkRegistrationConfig = configureSdkRegistration(sdkRegistrationConfig);
    }
    tracerProvider.register(sdkRegistrationConfig);
    // Re-register instrumentation with initialized provider. Patched code will see the update.
    instrumentation_1.registerInstrumentations({
        instrumentations,
        tracerProvider,
        meterProvider,
    });
}
initializeProvider();
//# sourceMappingURL=wrapper.js.map