"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const sdk_trace_node_1 = require("@opentelemetry/sdk-trace-node");
const sdk_trace_base_1 = require("@opentelemetry/sdk-trace-base");
const instrumentation_1 = require("@opentelemetry/instrumentation");
const resource_detector_aws_1 = require("@opentelemetry/resource-detector-aws");
const resources_1 = require("@opentelemetry/resources");
const instrumentation_aws_sdk_1 = require("@opentelemetry/instrumentation-aws-sdk");
const api_1 = require("@opentelemetry/api");
const core_1 = require("@opentelemetry/core");
// Use require statements for instrumentation to avoid having to have transitive dependencies on all the typescript
// definitions.
const { AwsLambdaInstrumentation } = require('@opentelemetry/instrumentation-aws-lambda');
const { DnsInstrumentation } = require('@opentelemetry/instrumentation-dns');
const { ExpressInstrumentation } = require('@opentelemetry/instrumentation-express');
const { GraphQLInstrumentation } = require('@opentelemetry/instrumentation-graphql');
const { GrpcInstrumentation } = require('@opentelemetry/instrumentation-grpc');
const { HapiInstrumentation } = require('@opentelemetry/instrumentation-hapi');
const { HttpInstrumentation } = require('@opentelemetry/instrumentation-http');
const { IORedisInstrumentation } = require('@opentelemetry/instrumentation-ioredis');
const { KoaInstrumentation } = require('@opentelemetry/instrumentation-koa');
const { MongoDBInstrumentation } = require('@opentelemetry/instrumentation-mongodb');
const { MySQLInstrumentation } = require('@opentelemetry/instrumentation-mysql');
const { NetInstrumentation } = require('@opentelemetry/instrumentation-net');
const { PgInstrumentation } = require('@opentelemetry/instrumentation-pg');
const { RedisInstrumentation } = require('@opentelemetry/instrumentation-redis');
const exporter_otlp_proto_1 = require("@opentelemetry/exporter-otlp-proto");
const index_1 = require("./eventDetection/index");
console.log('Registering OpenTelemetry');
const instrumentations = [
    new instrumentation_aws_sdk_1.AwsInstrumentation({
        suppressInternalInstrumentation: true,
    }),
    new AwsLambdaInstrumentation({
        requestHook: (span, { event = {} }) => {
            const eventType = index_1.detectEventType(event);
            span.setAttributes('faas.eventType', eventType);
            if (eventType === 'aws.apigateway.http') {
                span.setAttributes('faas.source', 'aws.apigateway');
                span.setAttributes('faas.accountId', event.requestContext.accountId);
                span.setAttributes('faas.apiId', event.requestContext.apiId);
                span.setAttributes('faas.resourceId', event.requestContext.resourceId);
                span.setAttributes('faas.domainPrefix', event.requestContext.domainPrefix);
                span.setAttributes('faas.domain', event.requestContext.domainName);
                span.setAttributes('faas.requestId', event.requestContext.requestId);
                span.setAttributes('faas.extendedRequestId', event.requestContext.extendedRequestId);
                span.setAttributes('faas.requestTime', event.requestContext.requestTime);
                span.setAttributes('faas.requestTimeEpoch', event.requestContext.requestTimeEpoch);
                span.setAttributes('faas.httpPath', event.requestContext.resourcePath);
                span.setAttributes('faas.httpMethod', event.requestContext.httpMethod);
                span.setAttributes('faas.xTraceId', event.headers && event.headers['X-Amzn-Trace-Id']);
                span.setAttributes('faas.userAgent', event.headers && event.headers['User-Agent']);
            }
            else if (eventType === 'aws.apigatewayv2.http') {
                span.setAttributes('faas.source', 'aws.apigatewayv2');
                span.setAttributes('faas.accountId', event.requestContext.accountId);
                span.setAttributes('faas.apiId', event.requestContext.apiId);
                span.setAttributes('faas.domainPrefix', event.requestContext.domainPrefix);
                span.setAttributes('faas.domain', event.requestContext.domainName);
                span.setAttributes('faas.requestId', event.requestContext.requestId);
                span.setAttributes('faas.requestTime', event.requestContext.time);
                span.setAttributes('faas.requestTimeEpoch', event.requestContext.timeEpoch);
                span.setAttributes('faas.httpPath', event.requestContext.http.path);
                span.setAttributes('faas.httpMethod', event.requestContext.http.method);
                span.setAttributes('faas.xTraceId', event.headers && event.headers['x-amzn-trace-id']);
                span.setAttributes('faas.userAgent', event.headers && event.headers['user-agent']);
            }
        }
    }),
    new DnsInstrumentation(),
    new ExpressInstrumentation(),
    new GraphQLInstrumentation(),
    new GrpcInstrumentation(),
    new HapiInstrumentation(),
    new HttpInstrumentation(),
    new IORedisInstrumentation(),
    new KoaInstrumentation(),
    new MongoDBInstrumentation(),
    new MySQLInstrumentation(),
    new NetInstrumentation(),
    new PgInstrumentation(),
    new RedisInstrumentation(),
];
// configure lambda logging
const logLevel = core_1.getEnv().OTEL_LOG_LEVEL;
api_1.diag.setLogger(new api_1.DiagConsoleLogger(), logLevel);
// Register instrumentations synchronously to ensure code is patched even before provider is ready.
instrumentation_1.registerInstrumentations({
    instrumentations,
});
async function initializeProvider() {
    const resource = await resources_1.detectResources({
        detectors: [resource_detector_aws_1.awsLambdaDetector, resources_1.envDetector, resources_1.processDetector],
    });
    let config = {
        resource,
    };
    if (typeof configureTracer === 'function') {
        config = configureTracer(config);
    }
    const tracerProvider = new sdk_trace_node_1.NodeTracerProvider(config);
    if (typeof configureTracerProvider === 'function') {
        configureTracerProvider(tracerProvider);
    }
    else {
        // defaults
        tracerProvider.addSpanProcessor(new sdk_trace_base_1.BatchSpanProcessor(new exporter_otlp_proto_1.OTLPTraceExporter()));
    }
    // logging for debug
    if (logLevel === api_1.DiagLogLevel.DEBUG) {
        tracerProvider.addSpanProcessor(new sdk_trace_base_1.SimpleSpanProcessor(new sdk_trace_base_1.ConsoleSpanExporter()));
    }
    let sdkRegistrationConfig = {};
    if (typeof configureSdkRegistration === 'function') {
        sdkRegistrationConfig = configureSdkRegistration(sdkRegistrationConfig);
    }
    tracerProvider.register(sdkRegistrationConfig);
    // Re-register instrumentation with initialized provider. Patched code will see the update.
    instrumentation_1.registerInstrumentations({
        instrumentations,
        tracerProvider,
    });
}
initializeProvider();
//# sourceMappingURL=wrapper.js.map