export default function eventType(event?: any): false | "aws.apigateway.http";
//# sourceMappingURL=slsIntegrationLambda.d.ts.map