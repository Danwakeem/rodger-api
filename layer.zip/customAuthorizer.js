"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.apigateway.authorizer';
function eventType(event = {}) {
    if (typeof event === 'object') {
        const hasMethodArn = event.methodArn;
        const hasType = ['TOKEN', 'REQUEST'].includes(event.type);
        return hasMethodArn && hasType ? type : false;
    }
    return false;
}
exports.default = eventType;
;
//# sourceMappingURL=customAuthorizer.js.map