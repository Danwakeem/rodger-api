export default function eventType(event?: any): false | "aws.apigatewayv2.http";
//# sourceMappingURL=apiGatewayV2.d.ts.map