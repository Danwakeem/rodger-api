'use strict';
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.detectEventType = void 0;
const alexaSkill_1 = __importDefault(require("./eventTypes/alexaSkill"));
const apiGateway_1 = __importDefault(require("./eventTypes/apiGateway"));
const apiGatewayV2_1 = __importDefault(require("./eventTypes/apiGatewayV2"));
const customAuthorizer_1 = __importDefault(require("./eventTypes/customAuthorizer"));
const cloudFront_1 = __importDefault(require("./eventTypes/cloudFront"));
const cloudwatchEvent_1 = __importDefault(require("./eventTypes/cloudwatchEvent"));
const cloudwatchLog_1 = __importDefault(require("./eventTypes/cloudwatchLog"));
const dynamodb_1 = __importDefault(require("./eventTypes/dynamodb"));
const firehose_1 = __importDefault(require("./eventTypes/firehose"));
const kinesis_1 = __importDefault(require("./eventTypes/kinesis"));
const s3_1 = __importDefault(require("./eventTypes/s3"));
const scheduled_1 = __importDefault(require("./eventTypes/scheduled"));
const ses_1 = __importDefault(require("./eventTypes/ses"));
const sns_1 = __importDefault(require("./eventTypes/sns"));
const sqs_1 = __importDefault(require("./eventTypes/sqs"));
const detectEventType = (event) => alexaSkill_1.default(event) ||
    // Custom authorizer must come before apiGateway because they share similar keys.
    customAuthorizer_1.default(event) ||
    apiGateway_1.default(event) ||
    apiGatewayV2_1.default(event) ||
    cloudFront_1.default(event) ||
    cloudwatchLog_1.default(event) ||
    firehose_1.default(event) ||
    kinesis_1.default(event) ||
    s3_1.default(event) ||
    scheduled_1.default(event) ||
    ses_1.default(event) ||
    sns_1.default(event) ||
    sqs_1.default(event) ||
    dynamodb_1.default(event) ||
    // Cloudwatch events should be last because it lacks distinguishing characteristics
    // and closely resembles a scheduled event
    cloudwatchEvent_1.default(event) ||
    null;
exports.detectEventType = detectEventType;
//# sourceMappingURL=index.js.map