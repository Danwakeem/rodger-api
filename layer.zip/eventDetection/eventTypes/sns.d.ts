export default function eventType(event?: any): false | "aws.sns";
//# sourceMappingURL=sns.d.ts.map