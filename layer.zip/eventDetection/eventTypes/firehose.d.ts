export default function eventType(event?: any): false | "aws.firehose";
//# sourceMappingURL=firehose.d.ts.map