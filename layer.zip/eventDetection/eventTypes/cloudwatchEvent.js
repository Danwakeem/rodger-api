"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.cloudwatch.event';
function eventType(event = {}) {
    return event.source && event.detail ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=cloudwatchEvent.js.map