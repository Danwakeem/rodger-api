"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.apigateway.http';
function eventType(event = {}) {
    const apiGatewayRequiredKeys = ['path', 'headers', 'requestContext', 'resource', 'httpMethod'];
    if (typeof event === 'object') {
        return apiGatewayRequiredKeys.every((key) => key in event) ? type : false;
    }
    return false;
}
exports.default = eventType;
;
//# sourceMappingURL=apiGateway.js.map