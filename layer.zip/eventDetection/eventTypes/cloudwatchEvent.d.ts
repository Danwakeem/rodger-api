export default function eventType(event?: any): false | "aws.cloudwatch.event";
//# sourceMappingURL=cloudwatchEvent.d.ts.map