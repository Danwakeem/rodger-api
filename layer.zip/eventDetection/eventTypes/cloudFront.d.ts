export default function eventType(event?: any): false | "aws.cloudfront";
//# sourceMappingURL=cloudFront.d.ts.map