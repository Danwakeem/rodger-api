export default function eventType(event?: any): false | "aws.s3";
//# sourceMappingURL=s3.d.ts.map