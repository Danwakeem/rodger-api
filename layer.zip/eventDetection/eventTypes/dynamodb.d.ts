export default function eventType(event?: any): false | "aws.dynamodb";
//# sourceMappingURL=dynamodb.d.ts.map