"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.cloudfront';
function eventType(event = {}) {
    const { Records = [] } = event;
    return Records[0] && Records[0].cf ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=cloudFront.js.map