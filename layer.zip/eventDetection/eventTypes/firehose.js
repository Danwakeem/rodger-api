"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.firehose';
function eventType(event = {}) {
    const { records = [] } = event;
    return event.deliveryStreamArn && records[0] && records[0].kinesisRecordMetadata ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=firehose.js.map