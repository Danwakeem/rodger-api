"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.apigateway.http';
const keys = ['body', 'method', 'principalId', 'stage'];
const keysThatNeedValues = ['identity.userAgent', 'identity.sourceIp', 'identity.accountId'];
function eventType(event = {}) {
    if (typeof event === 'object') {
        const keysArePresent = keys.every((key) => key in event);
        const valuesArePresent = keysThatNeedValues
            .map((key) => {
            return typeof (event === null || event === void 0 ? void 0 : event.key) !== 'undefined';
        })
            .filter(Boolean).length === keysThatNeedValues.length;
        return keysArePresent && valuesArePresent ? type : false;
    }
    return false;
}
exports.default = eventType;
;
//# sourceMappingURL=slsIntegrationLambda.js.map