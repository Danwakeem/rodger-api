"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.apigatewayv2.http';
function eventType(event = {}) {
    const apiGatewayV2RequiredKeys = ['rawPath', 'headers', 'requestContext', 'routeKey', 'version'];
    if (typeof event === 'object') {
        return apiGatewayV2RequiredKeys.every((key) => key in event) && event.version === '2.0'
            ? type
            : false;
    }
    return false;
}
exports.default = eventType;
;
//# sourceMappingURL=apiGatewayV2.js.map