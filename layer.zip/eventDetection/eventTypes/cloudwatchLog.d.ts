export default function eventType(event?: any): false | "aws.cloudwatch.log";
//# sourceMappingURL=cloudwatchLog.d.ts.map