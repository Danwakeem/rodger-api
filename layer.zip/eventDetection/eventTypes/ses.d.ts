export default function eventType(event?: any): false | "aws.ses";
//# sourceMappingURL=ses.d.ts.map