"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.ses';
function eventType(event = {}) {
    const { Records = [] } = event;
    const [firstEvent = {}] = Records;
    const { eventSource } = firstEvent;
    // test is for firstEvent.EventVersion === '1.0'
    return eventSource === 'aws:ses' ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=ses.js.map