export default function eventType(event?: any): false | "aws.sqs";
//# sourceMappingURL=sqs.d.ts.map