"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.sns';
function eventType(event = {}) {
    const { Records = [] } = event;
    const [firstEvent = {}] = Records;
    const { EventSource } = firstEvent;
    // test is for firstEvent.EventVersion === '1.0'
    return EventSource === 'aws:sns' ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=sns.js.map