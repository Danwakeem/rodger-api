"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.sqs';
function eventType(event = {}) {
    const { Records = [] } = event;
    const [firstEvent = {}] = Records;
    const { eventSource } = firstEvent;
    return eventSource === 'aws:sqs' ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=sqs.js.map