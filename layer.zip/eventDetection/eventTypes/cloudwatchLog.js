"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.cloudwatch.log';
function eventType(event = {}) {
    return event.awslogs && event.awslogs.data ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=cloudwatchLog.js.map