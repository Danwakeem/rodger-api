export default function eventType(event?: any): false | "aws.scheduled";
//# sourceMappingURL=scheduled.d.ts.map