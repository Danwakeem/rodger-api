"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.alexaskill';
function eventType(e = {}) {
    var _a, _b, _c, _d;
    return ((_a = e === null || e === void 0 ? void 0 : e.session) === null || _a === void 0 ? void 0 : _a.attributes) && ((_b = e === null || e === void 0 ? void 0 : e.session) === null || _b === void 0 ? void 0 : _b.user) && ((_c = e === null || e === void 0 ? void 0 : e.context) === null || _c === void 0 ? void 0 : _c.System) && ((_d = e === null || e === void 0 ? void 0 : e.request) === null || _d === void 0 ? void 0 : _d.requestId)
        ? type
        : false;
}
exports.default = eventType;
;
//# sourceMappingURL=alexaSkill.js.map