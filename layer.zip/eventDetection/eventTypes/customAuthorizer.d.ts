export default function eventType(event?: any): false | "aws.apigateway.authorizer";
//# sourceMappingURL=customAuthorizer.d.ts.map