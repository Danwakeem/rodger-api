"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.scheduled';
function eventType(event = {}) {
    return event.source === 'aws.events' ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=scheduled.js.map