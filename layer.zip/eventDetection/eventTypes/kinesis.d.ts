export default function eventType(event?: any): false | "aws.kinesis";
//# sourceMappingURL=kinesis.d.ts.map