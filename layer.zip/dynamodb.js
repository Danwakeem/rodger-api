"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const type = 'aws.dynamodb';
function eventType(event = {}) {
    const { Records = [] } = event;
    const [firstEvent = {}] = Records;
    const { eventSource } = firstEvent;
    return eventSource === 'aws:dynamodb' ? type : false;
}
exports.default = eventType;
;
//# sourceMappingURL=dynamodb.js.map