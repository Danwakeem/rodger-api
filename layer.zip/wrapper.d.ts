import { NodeTracerConfig, NodeTracerProvider } from '@opentelemetry/sdk-trace-node';
import { SDKRegistrationConfig } from '@opentelemetry/sdk-trace-base';
declare global {
    function configureTracerProvider(tracerProvider: NodeTracerProvider): void;
    function configureTracer(defaultConfig: NodeTracerConfig): NodeTracerConfig;
    function configureSdkRegistration(defaultSdkRegistration: SDKRegistrationConfig): SDKRegistrationConfig;
}
//# sourceMappingURL=wrapper.d.ts.map